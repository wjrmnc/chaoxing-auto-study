#!/bin/bash
# =============================================================================
#  学习通（超星）课程自动学习脚本 —— 一键安装脚本
#
#  适用：Debian / Ubuntu / 麒麟(Kylin) / CentOS / RHEL / Rocky / Alma /
#        Fedora / openSUSE / Arch / Alpine 等主流 Linux
#
#  用法：
#      bash install.sh                # 普通安装（自动检测发行版）
#      bash install.sh --cn           # 使用国内镜像加速（清华 pip 源等）
#
#  安装完成后：编辑 config.json 填账号/课程，再运行 ./run.sh
# =============================================================================
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE_DIR"

USE_CN=0
for arg in "$@"; do
  case "$arg" in
    --cn|--china) USE_CN=1 ;;
    *) ;;
  esac
done

RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; NC='\033[0m'
info()  { echo -e "${BLUE}[安装]${NC} $*"; }
ok()    { echo -e "${GREEN}[完成]${NC} $*"; }
warn()  { echo -e "${YELLOW}[提示]${NC} $*"; }
fail()  { echo -e "${RED}[失败]${NC} $*"; }

# ---------------------------------------------------------------------------
# 0. 环境检查
# ---------------------------------------------------------------------------
command -v python3 >/dev/null 2>&1 || { warn "未检测到 python3，将自动安装。"; }
command -v pip3  >/dev/null 2>&1 || true

# root 检测（非 root 时用 sudo）
SUDO=""
if [ "$(id -u)" != "0" ]; then
  if command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
    info "非 root 用户，使用 sudo 执行系统级操作。"
  else
    fail "需要 root 权限（当前非 root 且无 sudo），请切换 root 用户后重试。"
    exit 1
  fi
fi

# ---------------------------------------------------------------------------
# 1. 检测发行版与包管理器
# ---------------------------------------------------------------------------
DISTRO="未知"
PKG=""
INSTALL=""
if command -v apt-get >/dev/null 2>&1; then
  PKG="apt"; DISTRO="Debian/Ubuntu/麒麟(Kylin)系"
  INSTALL="apt-get install -y"
elif command -v dnf >/dev/null 2>&1; then
  PKG="dnf"; DISTRO="RHEL/Rocky/Alma/Fedora系"
  INSTALL="dnf install -y"
elif command -v yum >/dev/null 2>&1; then
  PKG="yum"; DISTRO="CentOS/RHEL系"
  INSTALL="yum install -y"
elif command -v zypper >/dev/null 2>&1; then
  PKG="zypper"; DISTRO="openSUSE系"
  INSTALL="zypper install -y --no-recommends"
elif command -v pacman >/dev/null 2>&1; then
  PKG="pacman"; DISTRO="Arch系"
  INSTALL="pacman -Sy --noconfirm"
elif command -v apk >/dev/null 2>&1; then
  PKG="apk"; DISTRO="Alpine系"
  INSTALL="apk add"
else
  fail "无法识别系统包管理器，请手动安装依赖后重试。"
  exit 1
fi
info "检测到发行版：${DISTRO}"

# ---------------------------------------------------------------------------
# 2. 安装系统依赖
# ---------------------------------------------------------------------------
SYS_DEPS="python3 python3-venv python3-pip wget curl git ca-certificates"
case "$PKG" in
  apt)
    info "apt 更新源并安装基础依赖（可能需要几分钟）..."
    $SUDO apt-get update -y >/dev/null 2>&1 || true
    $SUDO $INSTALL $SYS_DEPS
    ;;
  dnf|yum)
    info "$PKG 安装基础依赖..."
    $SUDO $INSTALL python3 python3-pip wget curl git ca-certificates
    $SUDO $INSTALL python3-devel gcc-c++ || true
    ;;
  zypper)
    info "zypper 安装基础依赖..."
    $SUDO $INSTALL python3 python3-pip python3-setuptools wget curl git ca-certificates
    ;;
  pacman)
    info "pacman 安装基础依赖..."
    $SUDO $INSTALL python python-pip python-virtualenv wget curl git ca-certificates
    ;;
  apk)
    info "apk 安装基础依赖..."
    $SUDO $INSTALL python3 py3-pip py3-virtualenv wget curl git ca-certificates
    ;;
esac

# ---------------------------------------------------------------------------
# 3. 创建虚拟环境
# ---------------------------------------------------------------------------
if [ ! -d venv ]; then
  info "创建 Python 虚拟环境 venv ..."
  python3 -m venv venv
else
  info "已存在 venv，复用。"
fi

# 国内镜像加速（可选）
PIP_EXTRA=""
if [ "$USE_CN" = "1" ]; then
  PIP_EXTRA="-i https://pypi.tuna.tsinghua.edu.cn/simple"
  info "使用清华 PyPI 镜像加速。"
fi

info "升级 pip 并安装 Python 依赖..."
./venv/bin/pip install --upgrade pip $PIP_EXTRA -q || true
./venv/bin/pip install -r requirements.txt $PIP_EXTRA

# ---------------------------------------------------------------------------
# 4. 安装 Playwright 浏览器（Chromium）
# ---------------------------------------------------------------------------
info "安装 Playwright Chromium 浏览器（首次下载约 150MB）..."
./venv/bin/playwright install --with-deps chromium || {
  warn "playwright install --with-deps 失败，尝试拆分为两步安装..."
  $SUDO ./venv/bin/playwright install-deps chromium || {
    warn "无法自动安装浏览器系统库（如受限环境/离线），可后续手动执行："
    warn "  ./venv/bin/playwright install-deps chromium"
  }
  ./venv/bin/playwright install chromium || {
    fail "Chromium 下载失败。"
    warn "国内网络可先设置镜像后重试："
    warn "  export PLAYWRIGHT_DOWNLOAD_HOST=https://npmmirror.com/mirrors/playwright/"
    warn "  bash install.sh"
    exit 1
  }
}

# ---------------------------------------------------------------------------
# 5. 生成配置文件
# ---------------------------------------------------------------------------
if [ ! -f config.json ]; then
  cp config.example.json config.json
  ok "已生成 config.json（请务必编辑填写账号！）"
else
  info "已存在 config.json，跳过生成。"
fi

# ---------------------------------------------------------------------------
# 6. 自检
# ---------------------------------------------------------------------------
echo
info "自检安装结果..."
./venv/bin/python - <<'PY'
import importlib
ok = True
for mod in ("playwright", "requests"):
    try:
        importlib.import_module(mod)
        print("  [OK] %-12s" % mod)
    except Exception as e:
        ok = False
        print("  [缺失] %s -> %s" % (mod, e))
try:
    from rapidocr_onnxruntime import RapidOCR
    print("  [OK] rapidocr-onnxruntime")
except Exception as e:
    print("  [缺失] rapidocr-onnxruntime -> %s（不影响视频学习，仅图片题需要）" % e)
    ok = True  # OCR 为可选
if ok:
    print("基础依赖全部就绪。")
else:
    print("存在缺失依赖，请检查上方提示。")
PY

echo
ok "安装完成！"
echo "------------------------------------------------------------"
echo " 下一步："
echo "  1) 编辑 config.json：填账号(手机号/学号)和密码、指定课程"
echo "  2) 运行：./run.sh             # 前台运行"
echo "  3) 或：./start.sh             # 后台运行(自动重启)，日志 run.log"
echo "  4) 查看进度：./status.sh"
echo "  5) 停止：./stop.sh"
echo "------------------------------------------------------------"
echo "  《使用教程.md》中有详细的课程指定与答疑说明。"
echo "------------------------------------------------------------"
