#!/bin/bash
# 查看运行状态与最近日志
cd "$(dirname "$0")"
echo "== 进程 =="
pgrep -af "venv/bin/python main.py" || echo "（未在运行）"
echo
echo "== 最近日志 =="
if [ -f run.log ]; then
  tail -n 20 run.log
else
  echo "（无 run.log，未启动过或由 systemd 管理）"
  journalctl --unit=cxbot --no-pager -n 20 2>/dev/null || true
fi
echo
echo "== 完成进度 (progress.json) =="
if [ -f progress.json ]; then
  python3 -c "import json;d=json.load(open('progress.json'));print('已完成课时数:',len(d))"
else
  echo "（暂无进度）"
fi
