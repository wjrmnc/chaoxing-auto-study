#!/bin/bash
# 前台运行学习脚本（推荐第一次跑，便于看日志/扫码）
# 用法：
#   ./run.sh                     # 使用 config.json 全部课程
#   ./run.sh --course "课程名"   # 只刷指定名称(关键字)的课程
#   ./run.sh --course A --course B
cd "$(dirname "$0")"
BASE_DIR="$(pwd)"

if [ ! -f config.json ]; then
  echo "未找到 config.json，请先：cp config.example.json config.json 并编辑填账号。"
  exit 1
fi
if [ ! -d venv ]; then
  echo "未找到虚拟环境，请先运行：bash install.sh"
  exit 1
fi

# 自动探测图形界面（有显示器时可弹出窗口扫码/验证码）
if [ -z "$DISPLAY" ]; then
  for d in :0 :1; do
    if xdpyinfo -display "$d" >/dev/null 2>&1; then
      echo "检测到显示器 $d，使用有头模式（可扫码/手动验证）"
      export DISPLAY="$d"
      break
    fi
  done
fi

cd "$BASE_DIR"
exec ./venv/bin/python main.py "$@"
