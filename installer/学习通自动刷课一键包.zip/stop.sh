#!/bin/bash
# 停止学习脚本
cd "$(dirname "$0")"
systemctl stop cxbot 2>/dev/null
systemctl reset-failed cxbot 2>/dev/null
pkill -f "venv/bin/python main.py" 2>/dev/null
sleep 1
if pgrep -f "venv/bin/python main.py" >/dev/null 2>&1; then
  echo "仍有进程残留，强制结束..."
  pkill -9 -f "venv/bin/python main.py" 2>/dev/null
fi
echo "已停止。进度已保存在 progress.json，下次启动自动续学。"
