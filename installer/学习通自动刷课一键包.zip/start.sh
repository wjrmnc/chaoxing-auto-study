#!/bin/bash
# 后台运行学习脚本（SSH 断开后继续跑，崩溃自动重启），日志写入 run.log
# 用法：
#   ./start.sh --course "课程名"   # 指定课程后后台启动
cd "$(dirname "$0")"
BASE_DIR="$(pwd)"

if [ ! -f config.json ]; then
  echo "未找到 config.json，请先：cp config.example.json config.json 并编辑填账号。"
  exit 1
fi
if [ ! -d venv ]; then
  echo "未找到虚拟环境，请先运行：bash install.sh"
  exit 1
fi

# 若已在运行则提示
if pgrep -f "venv/bin/python main.py" >/dev/null 2>&1; then
  echo "检测到学习脚本已在运行（可用 ./stop.sh 停止后再启动）。"
  pgrep -af "venv/bin/python main.py"
  exit 1
fi

cd "$BASE_DIR"
# 使用 systemd-run 托管，SSH 断开不中断，崩溃 15 秒后自动重启
ARGS=""
for a in "$@"; do
  ARGS="$ARGS '$a'"
done
if command -v systemd-run >/dev/null 2>&1; then
  systemctl stop cxbot 2>/dev/null
  systemctl reset-failed cxbot 2>/dev/null
  systemd-run --unit=cxbot --collect -p Restart=on-failure -p RestartSec=15 \
    bash -c "cd '$BASE_DIR' && ./venv/bin/python main.py $ARGS > run.log 2>&1"
  echo "已后台启动（systemd 托管），日志：tail -f run.log"
else
  nohup ./venv/bin/python main.py "$@" > run.log 2>&1 &
  echo "已后台启动（nohup，PID: $!），日志：tail -f run.log"
fi
