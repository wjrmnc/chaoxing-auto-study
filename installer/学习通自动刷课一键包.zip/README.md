# 学习通课程自动学习脚本 · 一键安装包使用教程

本教程介绍如何在 Linux 服务器 / 电脑上，用本一键包辅助完成学习通（超星）课程的
学习任务：自动登录 → 自动播放视频 → 自动答插入题/章节测验/作业（接入 AI 大模型）
→ 进度自动保存，断点续学。

> 请遵守所在学校/平台的规章制度，本脚本仅用于学习交流使用。

---

## 一、包内容一览

| 文件 | 作用 |
|------|------|
| `install.sh` | 一键安装脚本（自动装 Python、依赖、Chromium 浏览器） |
| `run.sh` | 前台运行（推荐第一次用，能看日志/扫码） |
| `start.sh` | 后台运行（SSH 断开也不中断，崩溃自动重启，日志写 `run.log`） |
| `stop.sh` | 停止后台任务 |
| `status.sh` | 查看进程、最近日志、已完成课时数 |
| `main.py` | 程序入口（支持 `--course` 指定课程） |
| `chaoxing.py` / `ai.py` / `ocr.py` | 核心逻辑 / AI 答题 / 图片 OCR |
| `config.example.json` | 配置模板（复制为 `config.json` 后填写） |
| `requirements.txt` | Python 依赖清单 |
| `README.md` | 本文档 |

---

## 二、安装（一步到位）

把整个文件夹传到你的 Linux 机器上（例如放到 `/root/chaoxing_auto`），然后：

```bash
cd /root/chaoxing_auto
bash install.sh
```

国内网络环境可加 `--cn` 使用清华镜像加速：

```bash
bash install.sh --cn
```

脚本会自动完成：

1. 识别发行版（Debian / Ubuntu / 麒麟 / CentOS / Rocky / Fedora / openSUSE / Arch 等）
2. 安装 `python3`、`venv`、`pip` 及基础工具
3. 创建虚拟环境 `venv` 并安装 Python 依赖
4. 下载 Playwright 的 Chromium 浏览器并装齐运行库
5. 生成 `config.json`

> **安装失败的常见情况**：Chromium 下载超时。国内网络可先执行
> `export PLAYWRIGHT_DOWNLOAD_HOST=https://npmmirror.com/mirrors/playwright/`
> 再重跑 `bash install.sh`。

---

## 三、填写配置

编辑 `config.json`：

```json
{
  "username": "18518184798",          ← 你的手机号 / 学号
  "password": "你的密码",              ← 学习通密码
  "headless": false,                  ← true=无头不弹窗（服务器用），false=有窗口（可扫码）
  "course_name": "",                  ← 指定单个课程名称关键字（可留空）
  "course_names": ["思政", "大学英语"], ← 指定多个课程（可留空）
  "video_rate": 1.0,                  ← 播放倍速（最高建议 2.0，过快会被风控）
  "finish_mode": "watch",             ← watch=真实观看（推荐，稳），fast=快速完成（易风控）
  "ai": {
    "base_url": "https://api.deepseek.com/v1",
    "api_key": "sk-...",              ← 填入你的 AI key（DeepSeek 等 OpenAI 兼容接口）
    "model": "deepseek-chat"
  }
}
```

### 指定课程有 3 种方式（三选一即可）

1. **改配置文件**：`course_name` 填一个，或 `course_names` 数组填多个。
   程序会按名称关键字模糊匹配你账号下的课程。

2. **命令行指定**（不改配置）：
   ```bash
   ./run.sh --course 课程名            # 只刷这一门
   ./run.sh --course 课程A --course 课程B   # 同时刷两门
   ```

3. **不指定**：`course_name` 和 `course_names` 都留空 = 刷账号下全部课程。

> 关键字是“模糊包含”匹配，例如填 `毛泽东` 会匹配名称含“毛泽东”的课程；
> 填多了或没匹配到任何课程会报错提示，不会误刷别的课。

---

## 四、启动

### 方式 A：前台运行（第一次建议）

```bash
./run.sh
# 或指定课程
./run.sh --course 课程名
```

前台能看到实时日志；如果有显示器，首次登录会弹出浏览器窗口（密码/扫码/验证码）。
**登录成功后窗口关闭，开始自动学习。**

### 方式 B：后台运行（推荐长期挂机）

```bash
./start.sh --course 课程名
```

- 用 systemd 托管：SSH 断开不中断，脚本崩溃 15 秒后自动重启
- 日志实时查看：`tail -f run.log`
- 查看状态：`./status.sh`
- 停止：`./stop.sh`

---

## 五、学习行为说明

- **视频**：按真实观看模式播放，每节视频看至结束（含中间插入题，会自动作答并点“继续”），
  页面自动进入下一节。进度每完成一节即写入 `progress.json`。
- **插入题 / 章节测验 / 作业**：
  - 单选、多选、判断、填空、简答都会自动作答并提交；
  - 接入 AI 大模型（DeepSeek 等）生成答案；
  - 图片题 / 图片选项会自动 OCR 识别后再交给 AI 判断；
  - AI 不可用时走“兜底答案”，保证题目能交、任务点能解锁。
- **断点续学**：中断或停止后再次启动，自动跳过已完成课时，从上次位置继续。
- **多课程**：按配置顺序逐门刷，一门刷完自动进入下一门。

### 常见配置项含义

| 配置 | 默认 | 说明 |
|------|------|------|
| `video_rate` | 1.0 | 视频倍速，建议 ≤2.0 |
| `max_courses` | 5 | 一次最多刷几门课程 |
| `per_lesson_timeout` | 5400 | 单节最长耗时(秒)，超时视为异常跳过 |
| `per_course_timeout` | 100000 | 单门课程最长耗时(秒) |
| `poll_interval` | 3.0 | 轮询间隔(秒) |
| `skip_done` | true | 跳过已完成的课时 |
| `progress_file` | progress.json | 进度文件 |

---

## 六、常见问题（FAQ）

**Q1：登录失败 / 提示验证码？**
在 `headless:false` 且有显示器的环境里运行（`./run.sh`），弹出窗口后手动完成
验证码或扫码即可，检测到登录成功后自动继续。服务器无显示器则建议配置好账号密码，
并确保网络能正常访问学习通。

**Q2：视频刷了但没进度？**
- 检查 `finish_mode` 是否为 `watch`、`video_rate` 是否过高（>2 易被风控）。
- 查看 `run.log` 里是否出现“问题信号”“等待真实完成”等提示。
- 检查网络到学习通是否稳定，脚本有自动重试。

**Q3：想改 AI 模型/接口？**
`ai.base_url`、`ai.api_key`、`ai.model` 支持所有 OpenAI 兼容接口
（DeepSeek、智谱 GLM、通义千问、OpenAI 等），改成对应地址和 key 即可。

**Q4：OCR 装不上？**
`rapidocr-onnxruntime` 仅在遇到图片题时用到，装不上不影响看视频与普通题目。
可稍后手动：`./venv/bin/pip install rapidocr-onnxruntime Pillow numpy`。

**Q5：如何重置进度重刷？**
删掉 `progress.json` 即可全部重刷（谨慎！）。单个课时想重刷，从 `progress.json`
里删除对应的“课时ID”键即可。

**Q6：长时间没反应 / 卡住？**
脚本每节有超时保护，单节超时会自动跳过；仍卡住可 `./stop.sh` 再 `./start.sh`，
进度已保存，会从断点续学。

---

## 七、升级 / 二次开发

核心逻辑在 `chaoxing.py`，入口参数在 `main.py`。需要自定义行为时：
- 答题策略：`chaoxing.py` 中 `answer_and_submit()` 方法
- AI 提示词：`ai.py`
- OCR：`ocr.py`

## 免责声明

1. 使用者**必须遵守所在学校及平台的规章制度**。本脚本仅用于**学习交流使用**。

2. 使用本脚本可能产生的任何后果（包括但不限于：账号异常、课程成绩无效、被平台标记或封禁、违反学校规定等），**作者概不负责**。使用者需自行评估风险，自愿承担全部责任。

3. 本脚本按"现状"提供，作者不对其正确性、可靠性及与平台兼容性作任何明示或默示的保证，亦不承担因使用本脚本而产生的任何直接或间接损失。

